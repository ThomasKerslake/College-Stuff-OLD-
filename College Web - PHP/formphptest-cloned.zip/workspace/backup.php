<html><body>
<?php
echo 'Hello world from Cloud9!';
;?><br><br>

Hello and welcome, <?php
echo $_POST['firstname']." ".$_POST['middlename'];
?><br>

<?php
echo $_POST['lastname'];
?><br>
----------------------------------------------------------- <br> <?php
echo "Your total number of cals is:".$_POST['cals'];
?>

<br>

<?php
if($cals >= 2500){
   echo "You have had enought cals.";
}
else if($cals < 2500){
    echo"You have not had enough cals";
}
?>

<br>
<br>

<?php
$gendercal = "";

function calcalcmale() {
    $gendercal === $cals;
    if ($gendercal < 2500){
        echo"u have enof yeeeee";
    }
}

echo "Your selected gender is:".$_POST['gender'];

if ($gender = "male"){
 
}
else{
    echo "Your gender is female.";
}
?>

<br>
</body>
</html>