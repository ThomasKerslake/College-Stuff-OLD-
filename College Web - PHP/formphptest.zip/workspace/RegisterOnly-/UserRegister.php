<head>
    <link rel="stylesheet" type="text/css" href="stylesheet.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300|PT+Mono|Raleway" rel="stylesheet">
</head>

<?php

            //Variables to hold connection detials e.g. database IP.
            $servername = getenv('IP'); //Cloud9 feature that obtains IP adress
            $username = 'thomaskerslake';
            $password = '';
            $database = 'Login';
            
            //Connect to my database
            $db = new mysqli($servername, $username, $password, $database);
            
            //Checking that we have connected
            if($db->connect_error)
            {
                
                //If there was an error, stop our PHP now before we go any further.
                //Also show the error on the screen
                die('Connection failed due to error: ' . $db->connect_error);
            }
            else {
                echo('You are connected to the chosen database: '. $database.".");
            }
            
        
   $username = $_POST['user'];
    $password = $_POST['pass'];
    
    //Create a query to get some data
            $checkrow = "SELECT * FROM users WHERE username = '$username'";//remove and pass
            //Run the query and store whatever data we get in the variable $result
            $resultcheck = $db->query($checkrow);



            
                if ($resultcheck->num_rows > 0) {

                    echo "<SCRIPT type='text/javascript'> 
                    alert('Username already in use. Please choose another.');
                    window.location.replace(\"Reg.html\");
                    </SCRIPT>";
                } 
                else  {
                    $sql = "INSERT INTO `users`(`id`, `username`, `password`) VALUES ('','$username','$password')"; 
                    $result = $db->query($sql);
                    echo "<SCRIPT type='text/javascript'> 
                    alert('Account Created.');
                    window.location.replace(\"index.html\");
                    </SCRIPT>";
                }  
            
             //Close the database connection afterwards
            $db->close();
        

?>
