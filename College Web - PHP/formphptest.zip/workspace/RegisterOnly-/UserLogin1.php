<head>
    <link rel="stylesheet" type="text/css" href="stylesheet.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300|PT+Mono|Raleway" rel="stylesheet">
</head>

<?php

            //Variables to hold connection detials e.g. database IP.
            $servername = getenv('IP'); //Cloud9 feature that obtains IP adress
            $username = 'thomaskerslake';
            $password = '';
            $database = 'Login';
            
            //Connect to my database
            $db = new mysqli($servername, $username, $password, $database);
            
            //Checking that we have connected
            if($db->connect_error)
            {
                
                //If there was an error, stop our PHP now before we go any further.
                //Also show the error on the screen
                error_log("Connection to the database could not be obtained.");
                die('Connection failed due to error: ' . $db->connect_error);
            }
            else {
                echo('You are connected to the chosen database: '. $database.'.   ');
            }
            
       
     $username = $_POST['user'];
        $password = $_POST['pass'];
    
    //Create a query to get some data
            $sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'"; 
            
            //Run the query and store whatever data we get in the variable $result
            $result = $db->query($sql);
            
            if ($result->num_rows > 0) {

                    echo "Welcome ". $username;
            }
            
            else {
                echo "Login Failed, that account does not exist.";
                error_log ("Login Failed, account details do not exist on the database.");
            }
                    
            //Close the database connection afterwards
            $db->close();
        

?>
