<html><body>
<?php
echo 'Hello world from Cloud9!';
;?><br><br>

<?php
$file_name = $_FILES["fileToUpload"]["name"];
echo "file is called: ".$file_name;

$file_name_correct = basename($_FILES["fileToUpload"]["name"]);
echo "<br/>File system path name: ".$file_name_correct;

$target_file = "uploads2/" . $file_name_correct;

$sucess = move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file);

if($sucess)echo "<br/>File Uploaded successfully";

echo "<p><img src='".$target_file."' /><p>";
echo "<p>".$_POST["caption"]."</p>";

?>



</body>
</html>