<html><!-- Start of HTML -->
    
    <head><!-- Font and CSS links --> 
        <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="../Sharedcss.css">
    </head>
    
<body>
    <h1 id="headerID">Image Uploaded</h1><!-- Page titel / header -->   
<hr><!-- UnderLine for h1 -->

<br> <!-- Brake in Page -->

<?php //Start of PHP Code

$file_name = $_FILES["fileToUpload"]["name"]; //Getting File name from index form
echo "<p style='color:white;'>File is called: </p>".$file_name;//Displaying the created variable 'file_name'

$file_name_correct = basename($_FILES["fileToUpload"]["name"]);//Stores files basename as variable called 'file_name_correct'.
echo "<br><p style='color:white;'>File system path name: </p>".$file_name_correct;//Display files basename to user.

$target_file = "uploads2/" . $file_name_correct;//Variable target_file set to send uploaded images to folder 'uploads2'.

$sucess = move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file);//Variable sucess moves image to target file

if($sucess)echo "<br><p style='color:white;'>File Uploaded successfully!</p>";//If the variable sucess has executed correctly, echo 'File Uploaded...'

echo "<p id='pinfotext'><img src='".$target_file."' /><p>";//Displays variable 'target_file' that has the image stored within on this page.
echo "<h1 id='headerID'>".$_POST["caption"]."</h1>";//Post (display) to the user the caption they gave the image.

// End of PHP Code ?>

<button id="Centbtn" style="margin-top: 10px;"><a href="../Homepage.html">Home</a></button><!-- Home Button -->

</body><!-- End of Body -->
</html><!-- End of HTML -->