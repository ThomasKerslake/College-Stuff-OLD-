
<head><!-- Font and CSS Links -->
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../Sharedcss.css">
</head>


<?php // Start of PHP

$uservalue = 0; //Global variable that is set to equal '0'
     
    $username = $_POST['name'];//Variable 'username' holds the input value from the form for 'users'
        $password = $_POST['pass'];//Variable 'password' holds the input value from the form for 'pass'
    
    //An 'if' statement will check what the user has entered against a predefined value of 'Admin'.
    if ($username == "Admin") {
        $uservalue = $uservalue + 1;
        // If the $username variable is equal to 'Admin', the global variable of $uservalue will have 1 added to its value.
    } 
    
    if ($password == "pass"){
        // If the $password variable is equal to 'pass', the global variable of $uservalue will have 1 added to its value.
        // This means that if both variables are true, uservalue will equal 2, if one is wrong it will equal 1 and 0 if none are true.
        $uservalue = $uservalue + 1;
    }
    
    if ($uservalue == 2){
        // If the value of the variable $uservalue is equal to 2
        // An echo will display to the user 'Welcome', along with what the variable $username holds (Admin).
        echo "<p id='pinfotext'>Welcome ". $username."</p>";
    }
    
    else {
    
        // If user did not get both of the variable correct (be true) to then make the value of 2 
        // they will then see "Login Failed".
        echo "<p id='pinfotext'>Username or password was incorrect, Login Failed.</p>";
        error_log("The password they entered for 'Simple Login' was not correct to the predefined value.");
    }


// Side note: Alternatively, a simple 'and' statement could be used to check if both statements are true in one go
// meaning only one if statement would need to be used.

?><!-- End PHP -->


