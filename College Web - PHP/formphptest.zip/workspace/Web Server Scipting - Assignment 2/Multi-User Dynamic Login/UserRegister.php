<head>
    <link rel="stylesheet" type="text/css" href="stylesheet.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300|PT+Mono|Raleway" rel="stylesheet">
</head>

<?php

            //Variables that will be used to connect to my database
            $servername = getenv('IP');
            $username = 'thomaskerslake';
            $password = '';
            $database = 'Login';
            
            //Connecting to my database
            $db = new mysqli($servername, $username, $password, $database);
            
            //This is to check that I have connected successfully to my database.
            if($db->connect_error)
            {
                
                //If there was an error the PHP code will stop here 'die'.
                //Also show the error on the screen
                error_log("Connection to the database could not be obtained.");
                die('Connection failed due to error: ' . $db->connect_error);
            }
            else {
                echo('You are connected to the chosen database: '. $database.".");
            }
            
        
   $username = $_POST['user']; //Variable 'username' hold the input value from the form for 'users'
        $password = $_POST['pass']; //Variable 'password' hold the input value from the form for 'pass'
    
     //Query to select all data table 'users' where there are values.
            $checkrow = "SELECT * FROM users WHERE username = '$username'";
            //Run the query above and store the data in the variable called 'resultcheck'
            $resultcheck = $db->query($checkrow);



                //If resultcheck is trying to input into the database a row of data that already is stored
                        //*(if the number of rows are more than '0' that hold this data)*
                //Display to the user an alert box that contains 'Username already in use...'
                if ($resultcheck->num_rows > 0) {

                    echo "<SCRIPT type='text/javascript'> 
                    alert('Username already in use. Please choose another.');
                    window.location.replace(\"Reg.html\");
                    </SCRIPT>";
                    //Take user back to Reg.html page
                } 
                
                //Else, if  no existing rows, insert into database from the form the values of $username and $password.
                else  {
                    $sql = "INSERT INTO `users`(`id`, `username`, `password`) VALUES ('','$username','$password')"; 
                    $result = $db->query($sql);
                    
                    //Display alert 'Account created.'
                    echo "<SCRIPT type='text/javascript'> 
                    alert('Account Created.');
                    window.location.replace(\"index.html\");
                    </SCRIPT>";
                    //Take user back to index.html page
                }  
            
             //Close the database connection afterwards
            $db->close();
        

?>
