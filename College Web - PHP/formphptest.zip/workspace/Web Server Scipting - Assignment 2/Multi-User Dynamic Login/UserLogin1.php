<head>
    <link rel="stylesheet" type="text/css" href="stylesheet.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300|PT+Mono|Raleway" rel="stylesheet">
</head>

<?php

            //Variables that will be used to connect to my database
            $servername = getenv('IP');
            $username = 'thomaskerslake';
            $password = '';
            $database = 'Login';
            
            //Connecting to my database
            $db = new mysqli($servername, $username, $password, $database);
            
            //This is to check that I have connected successfully to my database.
            if($db->connect_error)
            {
                
                //If there was an error the PHP code will stop here 'die'.
                //Also show the error on the screen
                error_log("Connection to the database could not be obtained.");
                die('Connection failed due to error: ' . $db->connect_error);
            }
            //If the connection works, the else will be executed and the PHP code will be continued to be processed
            else {
                echo('You are connected to the chosen database: '. $database.'.   ');
                //Display string + with what variable 'database' holds.
            }
            
       
     $username = $_POST['user']; //Variable 'username' holds the input value from the form for 'users'
        $password = $_POST['pass']; //Variable 'password' holds the input value from the form for 'pass'
    
    //Query to select all data table 'users' where there are values.
            $sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'"; 
            
            //Run the query above and store the data in the variable called 'result'
            $result = $db->query($sql);
            
            //If there are users stored in the database (more than '0' rows), display string + data within variable 'username'
            if ($result->num_rows > 0) {

                    echo "Welcome ". $username;
            }
            
            //If the condition above fails, display to the user, 'Login Failed...'
            //Add to error log the error that occurred.
            else {
                echo "Login Failed, that account does not exist.";
                error_log ("Login Failed, account details do not exist on the database.");
            }
                    
            //Close the connection to my database.
            $db->close();
        

?>
