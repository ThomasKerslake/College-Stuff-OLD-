<html><!-- HTML -->
    
<head><!-- Font and CSS Links -->
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet"><!-- Google Fonts -->
    <link rel="stylesheet" type="text/css" href="../Sharedcss.css">
</head><!-- End of Head / Links -->
   
  
    
<body><!-- Body -->

<h1 id="headerID">Save it to a file!</h1><!-- Page titel / header -->
	<p id="pinfotext">Remembered your choices? Save the choices you made throughout the story here e.g A,A,B,C,A!</p><!-- intro to page -->
		<hr><!-- UnderLine for h1 -->

<div id="linkBox">
    <form action="Write2File.php" method='post'>
    	<textarea name="EnteredText"></textarea>
    	<br><br><input type='submit' value='Add text'>
    </form>
</div>


<p>The text you have added to the file is shown bellow, visit the text file to see for yourself!</p>

<button  style="margin-top: 10px;"><a href="../Homepage.html">Home</a></button><!-- Home Button -->

<hr>

<?php

	    // The variable 'Mytext' will hold the opening of the text file 'MytextFile.txt.
	    // The text File is stored in the same location as this file is 'Write2File.php'.
	    // The file will be opend with 'fopen' in 'write' mode by 'W' so that the user can write in the file.
	$Mytext = fopen("MyTextFile.txt", "w");

	    // Next the users input is inserted into the the text file by 'POST'.
	    // The text that will be stored in the .txt file will be from 'EnteredText'.
	fwrite($Mytext, $_POST["EnteredText"]); 

	    // This then closes the .txt file 'MyTextFile.'
	fclose($Mytext);

	    // The text file is then opend in 'read' mode defined by "r".
	    // This allows the user to veiw the text but not edit it.
	$Mytext = fopen("MyTextFile.txt", "r");

	 // Now the file is in 'read' mode it is then displayed to the user so they can veiw its contense.
	echo fgets($Mytext); 
	fclose($Mytext);

?>
	
</body><!-- End Body -->
</html><!-- End HTML -->
