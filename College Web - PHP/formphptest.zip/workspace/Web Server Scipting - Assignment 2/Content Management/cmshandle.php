<?php
            
    //Variables that will be used to connect to my database
    $servername = getenv('IP');
    $username = 'thomaskerslake';
    $password = '';
    $database = 'Login';
    
    //Connecting to my database
    $db = new mysqli($servername, $username, $password, $database);
    
   //This is to check that I have connected successfully to my database.
    if($db->connect_error)
    {
        
        //If there was an error the PHP code will stop here 'die'.
                //Also show the error on the screen
        die('Connection failed due to error: ' . $db->connect_error);
    }
    
    //Query to get hold of the pages title
    $sql = "UPDATE cmspage SET title= '".$_POST["title"]."'";

    //Run the query and store as a variable called result
    $result = $db->query($sql);
    
    if(!$result)
    {
        error_log("Error updating title: ".$result->error);
    }
    
?>

<!-- HTML Code -->

<!DOCTYPE html>
<html>
    <head>
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../Sharedcss.css">
    </head>
    <body>
        <!-- Inform user the page has been updated -->
        <p id="pinfotext">The header has been updated!</p>
        <!-- Button to link user back to cms page -->
        <a href="cms.php"> <input id="Centbtn" style="color:black !important;" type="button" value="Back" name="Backbtn"></a>
    </body>
</html>