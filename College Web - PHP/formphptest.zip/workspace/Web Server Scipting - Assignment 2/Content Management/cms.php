<!DOCTYPE html>
<html><!-- HTML Start -->
    
  <head><!-- Font and Stylesheet Link -->
        <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="../Sharedcss.css">
   </head>
    
    
<body><!-- Body Start -->
    
<h1 id="headerID">Book Title</h1><!-- Page titel / header -->
<p id="pinfotext">Feel free to make up your own book title, enter in your title here!</p><!-- intro to page -->
<hr>


        <?php //Start Of PHP Code.
            
            //Variables that will be used to connect to my database
            $servername = getenv('IP');
            $username = 'thomaskerslake';
            $password = '';
            $database = 'Login';
            
            //Connecting to my database
            $db = new mysqli($servername, $username, $password, $database);
            
            //This is to check that I have connected successfully to my database.
            if($db->connect_error)
            {
                
                //If there was an error the PHP code will stop here 'die'.
                //Also show the error on the screen
                error_log("Connection to the database could not be obtained.");
                die('Connection failed due to error: ' . $db->connect_error);
            }
            
            //Query toselect all from table cmspage
            $sql = "SELECT * FROM cmspage";

            //Run the query and store it as a variable called result
            $result = $db->query($sql);
            
            //Check if there are any rows within the database
            if($result->num_rows > 0)
            {
                //If there is one, get the record 
                $only_record = $result->fetch_assoc();
            
                //Display the variable as the title
                echo "<h1 id='BookTitleID'>".$only_record['title']."</h1>"."<hr>";
                
            }else{
                
                //Else, write to my error log with this error
                error_log("No CMS records in table");
            }
            
            
        ?>
        
<!-- HTML Code for Form for data entry / Submit button -->
        
        <!-- Form start / Link to cmshandle page / Data transfer method 'Post'-->
            <br>
            <br>
        <form action="cmshandle.php" method="post">
            <input id="Centfrm" type="text" placeholder="Insert new book title" name="title" size="70">
            <br>
            <input id="Centbtn" style="color:black !important;" type="submit"/> <!-- Submit button to send data -->
        </form><!-- End of Form -->
        
        <button id="Centbtn" style="margin-top: 10px;"><a href="../Homepage.html">Home</a></button><!-- Home Button -->

    </body>
</html>