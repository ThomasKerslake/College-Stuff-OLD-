
<head><!-- Font and Stylesheet Link -->
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../Sharedcss.css">
</head>

<?php // Start of PHP Code.


 echo "<p>"; //HTML Paragraph
  echo "Your screen width: " . $_COOKIE['width']; //Display 'echo' screen width with 'width' Cookie.
   echo "<br/>"; //HTML Brake
    echo "Your screen height: ".$_COOKIE['height']; //Display 'echo' screen Height with 'Height' Cookie.
     echo "</p>"; //HTML Paragraph

//End of PHP Code ?>


<?php //Start of PHP Code


// Display 'echo' current browser info's.
echo "Browser Info: ".$_SERVER['HTTP_USER_AGENT'];

//End of PHP Code ?>

<br><!-- Page Brake -->
<button style="margin-top: 10px;"><a href="../Homepage.html">Home</a></button><!-- Home Button -->