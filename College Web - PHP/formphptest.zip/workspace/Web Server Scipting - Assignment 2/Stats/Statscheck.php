<head><!-- Font and CSS Links -->
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../Sharedcss.css">
    </head><!-- End of Head / Links -->
    
<body><!-- Start of Body -->

<h1 id="headerID">Stats</h1><!-- Page titel / header -->
<p id="pinfotext">Here you can see all of the logged stats that are stored on the database!</p><!-- intro to page -->
<hr><!-- Underline for h1 -->

<?php

            //Variables that will be used to connect to my database
            $servername = getenv('IP');
            $username = 'thomaskerslake';
            $password = '';
            $database = 'Login';
            
            //Connecting to my database
            $db = new mysqli($servername, $username, $password, $database);
            
            //This is to check that I have connected successfully to my database.
            if($db->connect_error)
            {
                
                //If there was an error the PHP code will stop here 'die'.
                //Also show the error on the screen
                error_log("Connection to the database could not be obtained.");
                die('Connection failed due to error: ' . $db->connect_error);
            }
            
       //Display to user 'connection successful'
      echo "<p>Connection successful</p>";
    
    //Select all from table stats
    $sql = "SELECT * FROM stats";
         
    echo "<br/>"; //Brake
    
    echo "<button id='Centbtn' style='margin-top: 10px;'><a href='../Homepage.html'>Home</a></button>";//Home Button
    
    $result = $db->query($sql); //Store in 'result' the query above
    
    //If there are more than '0' rows display to the user 'You got stats!'
    if($result->num_rows > 0)
    {
        echo "<p>You Got Stats!</p> <hr>";
        
        //The following code will run for each record, so while there is a record it will fetch it
        while($row = $result->fetch_assoc()) {
            
            //This will then display the stored info out to the user.
            echo "<p>Time:  " . $row["visit_time"]."</br>" ."  Browser Info: " . $row["browser_info"]. "</p>";
            
        }
        
    }

?>


</body><!-- End of Body -->