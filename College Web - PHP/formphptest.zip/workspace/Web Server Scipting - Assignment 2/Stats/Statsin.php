<!DOCTYPE html>
<html>
    <head><!-- Font and CSS Links -->
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../Sharedcss.css">
    </head><!-- End of Head / Links -->
    
    <body>
        
<h1 id="headerID">Stats</h1><!-- Page titel / header -->
    <p id="pinfotext">Your stats have just been generated!</p><!-- intro to page -->
        <hr><!-- Underline for h1 -->


    <?php //Start of PHP Code

    
    
    //Variables that will be used to connect to my database
            $servername = getenv('IP');
            $username = 'thomaskerslake';
            $password = '';
            $database = 'Login';
            
            //Connecting to my database
            $db = new mysqli($servername, $username, $password, $database);
            
            //This is to check that I have connected successfully to my database.
            if($db->connect_error)
            {
                
                //If there was an error the PHP code will stop here 'die'.
                //Also show the error on the screen
                error_log("Connection to the database could not be obtained.");
                die('Connection failed due to error: ' . $db->connect_error);
            }
            
    // Display to the user that the connection to the database was successful
    echo "<p>Your Connection to the database was successful!</p>";
    
    //Query that will insert into the table stats for field 'browser_info' the value of $_SERVER['HTTP_USER_AGENT'].
    $sql = "INSERT INTO stats(browser_info) VALUES ('" . $_SERVER['HTTP_USER_AGENT'] . "')";
         
    
    //Store in 'result' the query above
    $result = $db->query($sql);
    
    //If the variable 'result' is True, display to the user 'Stats have been inserted...'
    if($result == TRUE)
    {
        echo "<p>Stats have been inserted successfully!</p>";
    }

//End of PHP Code ?>


<a href="Statscheck.php"> <input type="button" value="Check stats!" name="Checkbtn"></a><!-- Button to check stats -->
<button style="margin-top: 10px;"><a href="../Homepage.html">Home</a></button><!-- Home Button -->

    </body>
</html>