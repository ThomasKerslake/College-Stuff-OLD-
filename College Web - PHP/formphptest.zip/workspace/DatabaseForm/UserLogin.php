<head>
    <link rel="stylesheet" type="text/css" href="stylesheet.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300|PT+Mono|Raleway" rel="stylesheet">
</head>

<?php

            //Variables to hold connection detials e.g. database IP.
            $servername = getenv('IP'); //Cloud9 feature that obtains IP adress
            $username = 'thomaskerslake';
            $password = '';
            $database = 'Login';
            
            //Connect to my database
            $db = new mysqli($servername, $username, $password, $database);
            
            //Checking that we have connected
            if($db->connect_error)
            {
                
                //If there was an error, stop our PHP now before we go any further.
                //Also show the error on the screen
                die('Connection failed due to error: ' . $db->connect_error);
            }
            else {
                echo('You are connected to the chosen database: '. $database. '. Row records: ');
            }
            
        //Query to retrive data
        $sql = "SELECT * FROM users";
        
        $result = $db->query($sql);
        
        echo $result->num_rows;
        
        //Check that we have some data in $result
            if ($result->num_rows > 0) {
                
                //Output the teachers as a list
                echo "<ul>";
                
                //The following code will run for each record
                while($row = $result->fetch_assoc()){
                    
                    //We can access each column by using square brackets [] and the name of the column
                    echo "<li>Name: " . $row["username"]. " " . "</li>" . "<li>Password: ". $row["password"]."</li>";
                    
                }}
        

?>
