<?php
 echo "<p>";
            echo "Your screen width: " . $_COOKIE['width'];
            echo "<br/>";
            echo "Your screen height: ".$_COOKIE['height'];
            echo "</p>";

?>
<?php

echo "Browser Info: ".$_SERVER['HTTP_USER_AGENT'];

?>