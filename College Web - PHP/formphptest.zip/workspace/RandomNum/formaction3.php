<html><body>
<?php

echo $echo_POST["thatbox"]

?>

<?php
echo mt_rand();
?>

<br>
</body>
</html>