<?php

    echo $_SERVER['HTTP_USER_AGENT'];
    
    //Create variables that will be used to connect to our database
    $servername = getenv('IP');
    $username = 'thomaskerslake';
    $password = '';
    $database = 'Login';
    
    //Connect to the database
    $db = new mysqli($servername, $username, $password, $database);
    
    //Check that we have connected successfully.
    //This condition is true if there was an error
    if($db->connect_error)
    {
        
        //If there was an error, stop our PHP now before we go any further.
        //Also show the error on the screen
        die('Connection failed due to error: ' . $db->connect_error);
    }
    
    echo "<p>Your Connection to the database was successful!</p>";
    
    $sql = "INSERT INTO stats(browser_info) VALUES ('" . $_SERVER['HTTP_USER_AGENT'] . "')";
         
    echo "<br/>";
    
    $result = $db->query($sql);
    
    if($result == TRUE)
    {
        echo "<p>Stats have been inserted successfully!</p>";
    }

?>

<!DOCTYPE html>
<html>
    <body>
    <a href="Statscheck.php"> <input type="button" value="Check stats!" name="Checkbtn"></a>
    </body>
</html>