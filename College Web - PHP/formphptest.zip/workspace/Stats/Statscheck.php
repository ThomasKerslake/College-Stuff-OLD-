<?php

            //Variables to hold connection detials e.g. database IP.
            $servername = getenv('IP'); //Cloud9 feature that obtains IP adress
            $username = 'thomaskerslake';
            $password = '';
            $database = 'Login';
            
            //Connect to my database
            $db = new mysqli($servername, $username, $password, $database);
            
            //Checking that we have connected
            if($db->connect_error)
            {
                
                //If there was an error, stop our PHP now before we go any further.
                //Also show the error on the screen
                error_log("Connection to the database could not be obtained.");
                die('Connection failed due to error: ' . $db->connect_error);
            }
            
       
      echo "<p>Connection successful</p>";
    
    $sql = "SELECT * FROM stats";
         
    echo "<br/>";
    
    $result = $db->query($sql);
    
    if($result->num_rows > 0)
    {
        echo "<p>You Got Stats!</p>";
        
        //The following code will run for each record
        while($row = $result->fetch_assoc()) {
            
            //We can access each column by using square brackets [] and the name of the column
            echo "<p>Time:  " . $row["visit_time"]."</br>" ."  Browser Info: " . $row["browser_info"]. "</p>";
            
        }
        
    }

?>