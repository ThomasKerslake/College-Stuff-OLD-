<html><body>
<?php
echo 'Hello world from Cloud9!';
;?><br><br>


Hello and welcome, <?php
echo $_POST['firstname']." ".$_POST['middlename'];
?><br>

<?php
echo $_POST['lastname'];
?><br>

Your total cal count is <?php

if ($cals = "5000"){
    echo $cals. ", what the hell is wrong with you?";
} else {
    echo ", good choice.";
}
?>

</body>
</html>