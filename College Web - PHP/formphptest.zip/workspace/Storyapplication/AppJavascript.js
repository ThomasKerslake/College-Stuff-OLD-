//This is a function that will cause other functions to execute once the site is loaded.
function homeOnload(){
    startTime();
        welcome();
}

//This a function that loaded on loading of the website
function navClock(){
   startTime(); 
}


//A simple welcome message that pops up when a user opens the home page, which is loaded via a onload function.
function welcome() {
    alert("Welcome To Tell'aTale!");   
}

var votenum = 0;
function Voteclick() {
if (votenum == 0){
    alert("Thank you for voting!");
    votenum += votenum + 1;
    console.log(votenum);
}

else{
    alert("Sorry, you have already voted...\nYou will be able to vote again next week!");
    }
}


//Code for the clock to display the hour, minutes and seconds and update as time goes on
function startTime() {
    var currentTime = new Date();
    var hours = currentTime.getHours(); //Sets variable H to current time (hours)
    var minuets = currentTime.getMinutes();//Sets variable M to current time (minuets)
    var seconds = currentTime.getSeconds(); //Sets variable S to current time (seconds)
    minuets = checkTime(minuets);
    seconds= checkTime(seconds);
    document.getElementById('txt').innerHTML =
    hours + ":" + minuets + ":" + seconds;
    var t = setTimeout(startTime, 500);
}
function checkTime(i) {
    if (i < 10) {i = "0" + i}; 
    return i;
}





//This is the function that is started once a user clicks on the start button
//This function includes the first story that a user can play through 
function story1(){
var FirstNextlevel =0;//Sets this var to equal '0'
var SecondNextlevel =0;//Sets this var to equal '0'
    
//Asking a user if they are ready   
var ans1 = prompt("Are you ready to start the story?\n\nAnswer either 'yes' or 'no'");

if(ans1 === "yes"){
alert("Enjoy.");
}
else{
alert("Come back soon!")
return
}

//This is the alert to help the user with how to play through the story
var helper = alert("When answering each section you will be given options to what you can do, to answer with one of the options type in the letter given to the action. \n\n E.g'A: Hide! -> type 'A' to perform action 'A' ");
    
//Alert warning the user that the story is about to begin.
alert("The story will now begin once you hit enter...")

//Story contents
alert("You and your group had been sent to protect a medium sized village from a possiable attack from the rebel force. It was quite, but that was not always a good thing; time went by and the thought of an attack from the rebel force became far less daunting.");
//Story contents
alert("However things changed fast, as night was comming you recive a call on your radio, alerting you of a possiable attack, rebels spotted to the west of the village.");
//Story contents
alert("Suddenly, as you are passing through the streets of the village, the building on your left combusts as an IED that was planted inside exploads.");
//Story contents
alert("You and your squad are luckily un injured, as you pick yourselves up you begin to see reble forces pushing toward the village, you begin taking fire and get to cover behind a small bank just infront of the village.");
//Story contents
alert("You notice that your radio was damaged by the blast, and would need fixing before you would be able to use it.");
//Story contents
var ans2 = prompt("In the mist of the combat, your enitre squad is begining to dwindle as the opposing force come closer and closer; the only radio you have was damaged from the blast, meaning support was not going to be avalible. You know that you are here to stop the rebels from reaching the village, and you and your squad are all that are left. \n\nWhat do you do?\n\nA: 'Hold your ground'\nB: 'Fall back into the town for better cover'\nC: 'Try to fix your radio'. ");

//Fist choice: Choice 'A'
//The Following Javascipt code that follows this format is all based off of changing the value of a var to change the outcome
//When an answer is chosen, it is selected by an if statment and a number is added to a variable
//depending on what that var is equal to, will change the outcome of what is shown to the user.
if(ans2 ==="A"){
alert("You decided to hold your ground to protect the village, you know its still only going to be a matter to time before the reble force becomes to strong.");
FirstNextlevel += FirstNextlevel +1
}
    
//Second choice: Choice 'B'
else if (ans2 ==="B"){
alert("You choose to fall back, while falling back you see that there are still many villagers that are trying to get to safty. You spot a mother trying to cross the street to hide from the gun fire.");
FirstNextlevel += FirstNextlevel +2
}
//Third choice: Choice 'C'
else if (ans2 ==="C"){
alert("Rummaging around in your bag, you look for the broken radio. You manage to to get a signal comming back through the radio. Calling for support was taking a long time, but you finaly get an answer.");
alert("Suppot was on its way.")
FirstNextlevel += FirstNextlevel +3
}

//Fist choice: Choice 'A'
if (FirstNextlevel === 1){
alert("The time has come to when you have to fall back, or risk being killed; you have given the people of the village enough time to fall back into safty; creating a small opening for you and your group as the rebel force regroup. You and your group fall back to the nearest building that you can use as cover.");
alert("You take out your radio and begin to try and fix it. You managed to get it working and call for support.");
}
//Second choice: Choice 'B'
if (FirstNextlevel === 2){
alert("You run over to try and provide help, but get shot in the process.\n\nYou Died.");
alert("The story has come to an end. Return to the home page to play another or play again!");
return
}
//Third choice: Choice 'C'
if (FirstNextlevel === 3){
alert("While waiting for support, get shot in the left arm. You are injurd, but not out of the fight.");
alert("You squad medic crawls over and raps up your arm to slow down the bleeding.");
}

//This is the last prompt that will allow a user to take a certain path within the story.
var ans3 = prompt("You begin to notice the sound of helicopters in the distance; not long after they begin to come into sight.\n\nWhat do you do?\n\nA: 'Run towards the chopper'\nB: 'Wait for support to reach you'");

//Fist choice: Choice 'A'
if(ans3 ==="A"){
alert("You and your squad begin to run towards the choppers.");
alert("You come under fire and take a shot to the chest. You know your not going to make it. \n\nYou Died.");
alert("The story has come to an end. Return to the home page to play another or play again!");
return
}
    
//Second choice: Choice 'B'
else if (ans3 ==="B"){
alert("The support finaly reaches you and you are taken to evacuation point.");
SecondNextlevel += SecondNextlevel +1
}

//As they selected 'B' they have now finished the story fully.
if(SecondNextlevel === 1){
    alert("You survived.");
    alert("You have now finished the story! Return to the home page to play another or play again!");

}
}
