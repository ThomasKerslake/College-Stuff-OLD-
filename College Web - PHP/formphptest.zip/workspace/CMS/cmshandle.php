<?php
            
    //Create variables that will be used to connect to our database
    $servername = getenv('IP');
    $username = 'thomaskerslake';
    $password = '';
    $database = 'Login';
    
    //Connect to the database
    $db = new mysqli($servername, $username, $password, $database);
    
    //Check that we have connected successfully.
    //This condition is true if there was an error
    if($db->connect_error)
    {
        
        //If there was an error, stop our PHP now before we go any further.
        //Also show the error on the screen
        die('Connection failed due to error: ' . $db->connect_error);
    }
    
    //Create our query to get hold of the pages title
    $sql = "UPDATE cmspage SET title= '".$_POST["title"]."'";

    //Run the query and store the result
    $result = $db->query($sql);
    
    if(!$result)
    {
        error_log("Error updating title: ".$result->error);
    }
    
    //header('Location: cms.php');
    
    exit();
    
?>