<!DOCTYPE html>
<html>
    <head>
        
    </head>
    <body>

        <?php 
            
            //Create variables that will be used to connect to our database
            $servername = getenv('IP');
            $username = 'thomaskerslake';
            $password = '';
            $database = 'Login';
            
            //Connect to the database
            $db = new mysqli($servername, $username, $password, $database);
            
            //Check that we have connected successfully.
            //This condition is true if there was an error
            if($db->connect_error)
            {
                
                //If there was an error, stop our PHP now before we go any further.
                //Also show the error on the screen
                die('Connection failed due to error: ' . $db->connect_error);
            }
            
            //Create our query to get hold of the pages title
            $sql = "SELECT * FROM cmspage";

            //Run the query and store the result
            $result = $db->query($sql);
            
            //Check we have something
            if($result->num_rows > 0)
            {
                //If we do, get hold of the record (there should be only one)
                $only_record = $result->fetch_assoc();
            
                //And display it as the title
                echo "<h1>".$only_record['title']."</h1>";
                
            }else{
                
                //Otherwise, write to our error logs
                error_log("No CMS records in table");
            }
            
            
        ?>
        
        <form action="cmshandle.php" method="post">
            <input type="text" placeholder="Insert new page title" name="title" />
            <input type="submit"/>
        </form>

    </body>
</html>